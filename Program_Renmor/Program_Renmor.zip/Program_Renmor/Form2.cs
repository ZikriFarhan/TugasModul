﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_Renmor
{
    public partial class Form2 : Form
    {
        private string nama;

        public Form2()
        {
            InitializeComponent();
            nama = Form1.SetValueFornama;
            label1.Text = nama;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
     
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            nama= Form1.SetValueFornama;
        }

        internal static void show()
        {
           
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
